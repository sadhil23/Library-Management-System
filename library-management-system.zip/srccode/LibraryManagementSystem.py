import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import sys
import os

library_file = os.path.join("data", "library.csv")
books_file = os.path.join("data", "books.csv")

def library():
    print("Reading the file...")
    df = pd.read_csv(library_file)
    print(df)

def new_member():
    df = pd.read_csv(library_file)
    print("Enter new member details:")
    member_id = int(input("Member ID: "))
    code = input("Code: ")
    name = input("Name: ")
    age = int(input("Age: "))
    place = input("Place: ")
    subject = input("Subject: ")
    issue_date = input("Issue Date (dd-mm-yyyy): ")
    return_date = input("Return Date (dd-mm-yyyy): ")
    fine = int(input("Fine: "))
    fee = int(input("Fee: "))

    df.loc[len(df)] = [member_id, code, name, age, place, subject,
                       issue_date, return_date, fine, fee]
    df.to_csv(library_file, index=False)
    print("New member added successfully!")
    print(df)

def fee_inc():
    print("Increasing member fees by 100")
    df = pd.read_csv(library_file)
    column_name = "Fine"
    if column_name in df.columns:
        df[column_name] += 100
    df.to_csv(library_file, index=False)
    print(df)

def sort_mem():
    print("Sorting members in ascending order by Names")
    df = pd.read_csv(library_file)
    df = df.sort_values("Names")
    print(df)

def top_bottom():
    print("Top 2 and Bottom 2 records")
    df = pd.read_csv(library_file)
    print("Top 2 records:")
    print(df.head(2))
    print("Bottom 2 records:")
    print(df.tail(2))

def modify():
    print("Change membership fee to null (treat 500 as null)")
    df = pd.read_csv(library_file, na_values=[500])
    print(df)

def add_newbooks():
    print("Add new books to the table")
    df = pd.read_csv(books_file)
    bookid = int(input("Book ID: "))
    code = input("Code: ")
    author = input("Author: ")
    price = int(input("Price: "))
    stock = int(input("Stock: "))
    status = input("Status: ")
    title = input("Title: ")

    df.loc[len(df)] = [bookid, code, author, price, stock, status, title]
    df.to_csv(books_file, index=False)
    print("Book added successfully!")
    print(df)

def author():
    print("Sorting author names in descending order")
    df = pd.read_csv(books_file)
    df = df.sort_values("Author", ascending=False)
    print(df)

def bar_plot():
    print("Printing bar plot of Book ID vs Price")
    df = pd.read_csv(books_file)
    x = df['bookid']
    y = df['Price']
    plt.xlabel('Book ID')
    plt.ylabel('Price')
    plt.title('Book ID and Price')
    plt.bar(x, y, color='red')
    plt.show()

print("*****************  LIBRARY MANAGEMENT PROJECT  ***********************")
print("*****************  A book is a gift you can open again and again!! *****************")
print("1. Read csv file - library")
print("2. Add new member in library file")
print("3. Increase the membership fee")
print("4. Display the names in ascending order")
print("5. Read two records from top and two from bottom from - member")
print("6. Modify membership fee to null")
print("7. Add new books to file - books")
print("8. Display name of authors in descending order")
print("9. To display the bar plot")
print("*****************  A reader lives a thousand lives before they die!!! ***************")

opt = int(input("Enter your choice: "))

if opt == 1:
    library()
elif opt == 2:
    new_member()
elif opt == 3:
    fee_inc()
elif opt == 4:
    sort_mem()
elif opt == 5:
    top_bottom()
elif opt == 6:
    modify()
elif opt == 7:
    add_newbooks()
elif opt == 8:
    author()
elif opt == 9:
    bar_plot()
else:
    print("Invalid choice")

print("*****************  A room without books is like a body without soul!! ***************")
