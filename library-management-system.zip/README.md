# Library Management System

This project is a Library Management System built using Python and Pandas.  
It automates library operations like issuing books, returning books, maintaining student info, and managing stock.

## Features
- Issue and return books
- Manage student information
- Track fines and delays
- Stock management and search

## Requirements
- Python 3.x
- pandas

## Installation
```bash
pip install -r requirements.txt
```

## Usage
```bash
python src/main.py
```
